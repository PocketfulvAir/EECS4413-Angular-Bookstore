import java.util.List;


import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class Tester {
	// Repos
	private final static String USER = "users";
	private final static String CATEGORY = "categories";
	private final static String ORDER = "orders";
	private final static String BOOK = "books";
	// Actions
	private final static String GETALL = "/get";
	private final static String GETALLREVIEWS = "/getreviews";
	private final static String GETREPORT = "/getreport";
	private final static String GETTOP = "/gettopten";
	private final static String GETUSER = "/byuser?username=";
	private final static String GETBOOKINFO = "/getProductInfo?productId=";
	private final static String GETORDERBYNUM = "/getOrderByNum?partNumber=";
	private final static String POSTREVIEW = "/addreview";
	private final static String POSTORDER = "/add";
	private final static String POSTUSER = "/add";

	// Get Test
	private final static String BOOKID = "13111526";
	private final static String BOOK1 = BOOK + GETALL;
	private final static String BOOK2 = BOOK + GETALLREVIEWS;
	private final static String BOOK3 = BOOK + GETREPORT;
	private final static String BOOK4 = BOOK + GETTOP;
	private final static String BOOK5 = BOOK + GETBOOKINFO + BOOKID;
	private final static String CATEGORY1 = CATEGORY + GETALL;
	private final static String ORDER1 = ORDER + GETALL;
	private final static String ORDER2 = ORDER + GETORDERBYNUM + BOOKID;
	private final static String USER1 = USER + GETALL; 
	private final static String USERNAME = "user";
	private final static String USER2 = USER + GETUSER + USERNAME;
	
	// POST Test
	private final static String AREVIEW1 = BOOK + POSTREVIEW;
	private final static String AUSER1 = USER + POSTUSER;
	private final static String AORDER1 = ORDER + POSTORDER;
	
	//JSON Inputs
	private final static String IREVIEW = "{\"bid\":\"1234567890123\",\"review\":\"Totally a review\"}";
	private final static String IUSER = "{\"username\":\"someuser\","
			+ "\"password\":\"insecurepassword\","
			+ "\"email\":\"anemail@email.com\","
			+ "\"type\":\"user\","
			+ "\"billing\":\"123 address circle\","
			+ "\"mailing\":\"123 address circle\"}";
	private final static String IORDER = "{\"oid\":1213634,"
			+ "\"username\":\"auser\","
			+ "\"date\":\"DECEMBER 8\","
			+ "\"status\":\"Pending\","
			+ "\"price\": 12.20}";
	
	
	public static void main(String[] args) {
		try {
			Client client = Client.create();
			String action = USER1;
			//String input = IREVIEW;
			String url = "http://localhost:8080/" + action;
			System.out.println(url);
			WebResource webRes = client.resource(url);
			ClientResponse response = webRes.accept("application/json").get(ClientResponse.class);
			//ClientResponse response = webRes.type("application/json").post(ClientResponse.class, input);
			
			// GET RESPONSE TEST
			if (response.getStatus() != 200) {
	           throw new RuntimeException("Failed : HTTP error code : "
	            + response.getStatus());
	        }
	        /*
			//POST RESPONSE TEST
			if (response.getStatus() != 201 && response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
                 + response.getStatus());
			}
			*/
	        String output = response.getEntity(String.class);

	        System.out.println("Output from Server .... \n");
	        System.out.println(output);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
